/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h> 
using namespace std; 

struct Node{
    int data;
    Node* next;
    Node(int d){
        data=d;
        next=NULL;
    }
};

//method 2(using do while loop)
Node *printclink(Node *head)
{
    if(head==NULL)
    {
        return NULL;
    }
    Node *curr=head;
    do{
        cout<<curr->data<<" ";
        curr=curr->next;
        
    }while(curr!=head);
}

/*naive method
Node *insertend(Node *head,int n)
{
    Node *temp=new Node(n);
    if(head==NULL)
    {
        temp->next=temp;
        return temp;
        
    }
    else
    {
        Node *curr=head;
        while(curr->next!=head)
        {
            curr=curr->next;
        }
        curr->next=temp;
        temp->next=head;
        return head;
    }
}*/
//efficient solution
Node *insertend(Node *head,int n)
{
    Node *temp=new Node(n);
    if(head==NULL)
    {
        temp->next=temp;
        return temp;
        
    }
    else
    {
        temp->next=head->next;
        head->next=temp;
        
        int t=head->data;
        head->data=temp->data;
        temp->data=t;
        
        return temp;
    }
}
int main() 
{ 
	Node *head=new Node(10);
	head->next=new Node(5);
	head->next->next=new Node(20);
	head->next->next->next=new Node(15);
	head->next->next->next->next=head;

	printclink(head);
	cout<<endl;
	head=insertend(head,30);
	printclink(head);
} 

