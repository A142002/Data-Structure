/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h> 
using namespace std; 

struct Node{
    int data;
    Node* next;
    Node(int d){
        data=d;
        next=NULL;
    }
};
/* method1(using for loop)
Node *printclink(Node *head)
{
    if(head==NULL)
    {
        return NULL;
    }
    cout<<head->data<<" ";
    for(Node *curr=head->next;curr!=head;curr=curr->next)
    {
        cout<<curr->data<<" ";
    }
}*/
//method 2(using do while loop)
Node *printclink(Node *head)
{
    if(head==NULL)
    {
        return NULL;
    }
    Node *curr=head;
    do{
        cout<<curr->data<<" ";
        curr=curr->next;
        
    }while(curr!=head);
}
int main() 
{ 
	Node *head=new Node(10);
	head->next=new Node(5);
	head->next->next=new Node(20);
	head->next->next->next=new Node(15);
	head->next->next->next->next=head;

	printclink(head);
} 

