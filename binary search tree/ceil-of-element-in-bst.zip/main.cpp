/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

struct Node{
    int key;
    Node *left,*right;
    Node(int x)
    {
        key=x;
        left=NULL;
        right=NULL;
    }
};

Node *ceilele(Node *root,int n)
{
    Node *res=NULL;
    while(root!=NULL)
    {
        if(root->key==n)
           return root;
        else if(root->key>n)
        {  res=root;
           root=root->left;
        }
        else
        {
            //res=root;
            root=root->right;
        }
    }
    return res;
}

int main()
{
    Node *root=new Node(50);
    root->left=new Node(30);
    root->left->left=new Node(20);
    root->left->right=new Node(40);
    root->right=new Node(70);
    root->right->left=new Node(60);
    root->right->left->left=new Node(55);
    root->right->right=new Node(80);
    cout<<(ceilele(root,25)->key);
    
}