/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

struct Node{
    int key;
    Node *left,*right;
    Node(int x)
    {
        key=x;
        left=NULL;
        right=NULL;
    }
};

//recursion 
/*
Node *insert(Node *root, int x){
    if(root==NULL)
        return new Node(x);
    if(root->key<x)
        root->right=insert(root->right,x);
    else if(root->key>x)
        root->left=insert(root->left,x);
    return root;
} 
*/
void inorder(Node *root){
    if(root!=NULL){
        inorder(root->left);
        cout<<root->key<<" ";
        inorder(root->right);    
    }
} 

//iterative search
Node *insert(Node *root,int x)
{
   Node *temp=new Node(x);
   Node *parent=NULL, *curr=root;
   while(curr!=NULL)
   {
       parent=curr;
       if(curr->key<x)
         curr=curr->right;
       else if(curr->key>x)
         curr=curr->left;
       else
         return root;    //use when element is already in tree
         
   }
   if(parent==NULL)
     return temp;
   if(parent->key<x)
     parent->right=temp;
   else
     parent->left=temp;
     
     return root;
}


int main()
{
    Node *root=new Node(15);
    root->left=new Node(5);
    root->left->left=new Node(3);
    root->right=new Node(20);
    root->right->left=new Node(18);
    root->right->left->left=new Node(16);
    root->right->right=new Node(80);
    root=insert(root,2);
    inorder(root);
}