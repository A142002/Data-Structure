#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

int maxguest(int a[],int b[], int n)
{
    sort(a,a+n);
    sort(b,b+n);
    int i=1,j=0,curr=1,res=1;
    while(i<n && j<n)
    {
        if(a[i]<b[j])
        {
            curr++;
            i++;
        }
        else
        {
            curr--;
            j++;
        }
        res=max(res,curr);
    }
    return res;
}

int main()
{
    int n;
    cout << "enter size of array:";
    cin >> n;
    int a[n],b[n];
    cout << "enter array1:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    cout << "enter array2:";
    for (int i = 0; i < n; i++)
    {
        cin >> b[i];
    }
    
   cout<<maxguest(a,b,n)<<" ";
    
    
    
    
}





