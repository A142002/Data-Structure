/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>
using namespace std;

void partition(int a[],int n,int low,int high,int pivot)
{
    int temp[n],index=0;
    for(int i=low;i<=high;i++)
    {
        if(a[i]<=a[pivot] )
        {
           temp[index]=a[i]; 
           index++;
        }
          
          
    }
    for(int j=low;j<=high;j++)
    {
        if(a[j]>a[pivot])
        {
           temp[index]=a[j]; 
           index++;
        }
          
          
    }
    for(int k=low;k<=high;k++)
    {
        a[k]=temp[k-low];
    }
    
    
}


int main() {
    int n, low,high,pivot;

    cout << "Enter size of array1: ";
    cin >> n;
    int a[n];

    cout << "Enter array1: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    cout<<"enter low,high,pivot:";
    cin>>low>>high>>pivot;

    

    partition(a,n,low,high,pivot);
    cout << "array1 after sorting: ";
    for (int i = 0; i < n; i++) {
        cout<< a[i]<<" ";
    }

    return 0;
}

