/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>
#include<climits>
using namespace std;
/*void selectionsort(int arr[],int n)
{
    
    int temp[n];
    for(int i=0;i<n;i++)
    {
     int min=0;
     for(int j=1;j<n;j++)
       {
           if(arr[j]<arr[min])
              min=j;
       }
       temp[i]=arr[min];
       arr[min]=INT_MAX;
    }
    for(int i=0;i<n;i++)
    {
        arr[i]=temp[i];
    }
}*/

//optimal solution
void selectionsort(int arr[],int n)
{
    
  
    for(int i=0;i<n;i++)
    {
     int min=i;
     for(int j=i+1;j<n;j++)
       {
           if(arr[j]<arr[min])
              min=j;
       }
     swap(arr[i],arr[min]);
    }
}


int main()
{
    int n;
    cout<<"enter array size:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    selectionsort(arr,n);
    
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}