#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

int arrinversion(int arr[],int n)
{
    int res=0;
    for(int i=0;i<n-1;i++)
    {
        for(int j=i;j<n;j++)
        {
            if(arr[i]>arr[j])
             {
                 res++;
             }
        }
    }
    return res;
}
int main()
{
    int n;
    cout << "enter size of array1:";
    cin >> n;
    int a[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    
    
    cout<<arrinversion(a,n);
}



