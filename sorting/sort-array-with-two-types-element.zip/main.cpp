#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

void segregateposneg(int a[],int n)
{
    
    int i=-1,j=n;
    while(true)
    {
        do{i++;}while(a[i]<0);
        do{j--;}while(a[j]>=0);
        if(i>=j)
          return;
        swap(a[i],a[j]);
    }
    /*int temp[n],i=0;
    for(int j=0;j<n;j++)
    {
        if(a[j]<0)
        //if(a[j]%2==0) for even element
        {
            temp[i]=a[j];
            i++;
        }
    }
    for(int j=0;j<n;j++)
    {
        if(a[j]>0)
        //if(a[j]%2!=0) for odd element
        {
            temp[i]=a[j];
            i++;
        }
    }
    for(int j=0;j<n;j++)
    {
        a[j]=temp[j];
    }*/
    
}
int main()
{
    int n;
    cout << "enter size of array1:";
    cin >> n;
    int a[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    
    segregateposneg(a,n);
    cout << "array after sorting:";
    for (int i = 0; i < n; i++)
    {
        cout<<a[i]<<" ";
    }
    
    
    
}




