#include <iostream>
#include <algorithm>
using namespace std;

#define RANGE 255

string countSort(string arr) {
    int count[RANGE + 1] = {0}; // Initialize count array with 0

    // Count the occurrence of each character
    for (char ch : arr) {
        count[ch]++;
    }

    // Modify the count array to store the actual position of each character
    for (int i = 1; i <= RANGE; i++) {
        count[i] += count[i - 1];
    }

    string output = arr;

    // Build the sorted output string
    for (int i = arr.length() - 1; i >= 0; i--) {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }

    // Return the sorted string
    return output;
}

int main() {
    int n;
    cin >> n;
    string arr;
    cin >> arr;

    cout << countSort(arr) << endl;
    return 0;
}
