/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>
using namespace std;
//if want hoare partition use hoare function here
int partition(int a[],int low,int high)
{
  int pivot=a[high];
  int i=low-1;
  for(int j=low;j<=high-1;j++)
  {
      if(a[j]<pivot)
      {
          i++;
          swap(a[i],a[j]);
      }
  }
    
    swap(a[i+1],a[high]);
    return(i+1);
}

void quicksort(int arr[],int l,int h)
{
    if(l<h)
    {
        int p=partition(arr,l,h);
        quicksort(arr,l,p-1);
        quicksort(arr,p+1,h);
    }
    return;
}


int main() {
    int n, low,high;

    cout << "Enter size of array1: ";
    cin >> n;
    int arr[n];

    cout << "Enter array1: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    
    cout<<"enter low,high:";
    cin>>low>>high;

    quicksort(arr,low,high);
    cout << "after partition: ";
    for (int i = 0; i < n; i++) {
        cout<<arr[i]<<" ";
    }
    return 0;
}


