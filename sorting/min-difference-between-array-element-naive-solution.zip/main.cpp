#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

int mindiff(int arr[],int n)
{
    int res=INT_MAX;
    for(int i=1;i<n;i++)
    {
        for(int j=0;j<i;j++)
        {
            res=min(res,abs(arr[i]-arr[j]));
        }
    }
    return res;
}
int main()
{
    int n,k;
    cout << "enter size of array:";
    cin >> n;
    int arr[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    
    cout<<mindiff(arr, n);
}

//time complexity theta(n*n)

