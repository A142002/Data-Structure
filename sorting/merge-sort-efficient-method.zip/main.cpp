/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>
using namespace std;

void mergesort(int a[], int b[], int n, int m) 
{
    
    int i=0,j=0;
    while(i<n && j<m)
    {
        if(a[i]<=b[j])
        {
            cout<<a[i]<<" ";
            i++;
        }
        else
        {
            cout<<b[j]<<" ";
            j++;
        }
    }
    while(i<n)
    {
        cout<<a[i]<<" ";
        i++;
    }
    
   while(j<m)
    {
        cout<<b[j]<<" ";
        j++;
    }
}


int main() {
    int n, m;

    cout << "Enter size of array1: ";
    cin >> n;
    int a[n];

    cout << "Enter array1: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    cout << "Enter size of array2: ";
    cin >> m;
    int b[m];

    cout << "Enter array2: ";
    for (int i = 0; i < m; i++) {
        cin >> b[i];
    }

    mergesort(a, b, n, m);

    return 0;
}

