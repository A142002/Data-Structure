#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

/*int kthsmallest(int arr[],int n,int k)
{
    sort(arr,arr+n);//sort(arr,arr+n,greater<int>()); for descending order sorting
    return arr[k-1];
}*/
int partition(int a[],int low,int high)
{
  int pivot=a[high];
  int i=low-1;
  for(int j=low;j<=high-1;j++)
  {
      if(a[j]<pivot)
      {
          i++;
          swap(a[i],a[j]);
      }
  }
    
    swap(a[i+1],a[high]);
    return(i+1);
}
int kthsmallest(int a[],int n,int k )
{
    int l=0,r=n-1;
    while(l<=r)
    {
        int p=partition(a,l,r);
        if(p==k-1)
          return a[p];
        else if(p>k-1)
           r=p-1;
           
        else
          l=p+1;
          
    }
}
int main()
{
    int n,k;
    cout << "enter size of array1:";
    cin >> n;
    int a[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    cout<<"enter k:";
    cin>>k;
    
    cout<<kthsmallest(a,n,k);
}




