#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

/*void sort(int a[],int n)
{
    int temp[n], i=0;
    for(int j=0;j<n;j++)
    {
        if(a[j]==0)
        {
            temp[i]=a[j];
            i++;
        }
    }
    for(int j=0;j<n;j++)
    {
        if(a[j]==1)
        {
            temp[i]=a[j];
            i++;
        }
    }
    for(int j=0;j<n;j++)
    {
        if(a[j]==2)
        {
            temp[i]=a[j];
            i++;
        }
    }
    for(int j=0;j<n;j++)
    {
        a[j]=temp[j];
    }
}*/
int sort(int arr[],int n)
{
    int l=0,mid=0,h=n-1;
    while(mid<=h)
    {
        if(arr[mid]==0)
        {
            swap(arr[mid],arr[l]);
            l++;
            mid++;
        }
        else if(arr[mid]==1)
        {
            mid++;
        }
        else
        {
            swap(arr[mid],arr[h]);
            h--;
        }
    }
}
int main()
{
    int n;
    cout << "enter size of array1:";
    cin >> n;
    int a[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    
    sort(a,n);
    cout << "array after sorting:";
    for (int i = 0; i < n; i++)
    {
        cout<<a[i]<<" ";
    }
    
    
    
}





