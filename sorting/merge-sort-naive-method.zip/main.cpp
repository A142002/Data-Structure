#include <iostream>
#include <algorithm>
using namespace std;

void mergesort(int a[], int b[], int n, int m) {
    int size = n + m;
    int c[size];

    for (int i = 0; i < n; i++)
        c[i] = a[i];

    for (int j = 0; j < m; j++)
        c[j + n] = b[j];

    sort(c, c + size);

    for (int i = 0; i < size; i++) {
        cout << c[i] << " ";
    }
}

int main() {
    int n, m;

    cout << "Enter size of array1: ";
    cin >> n;
    int a[n];

    cout << "Enter array1: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    cout << "Enter size of array2: ";
    cin >> m;
    int b[m];

    cout << "Enter array2: ";
    for (int i = 0; i < m; i++) {
        cin >> b[i];
    }

    mergesort(a, b, n, m);

    return 0;
}
