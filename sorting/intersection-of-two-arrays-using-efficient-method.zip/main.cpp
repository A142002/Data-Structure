#include <iostream>
#include <algorithm>
#include<bits/stdc++.h> 
using namespace std;

void intersection(int a[],int n,int b[],int m)
{
    int i=0,j=0;
    while(i<n && j<m)
    {
        if(i>0 && a[i]==a[i-1])
        {
           i++;
           continue;
        }
        if(a[i]<b[j])
        {
            i++;
        }
        else if(a[i]>b[j])
        {
            j++;
        }
        else
        {
            cout<<a[i]<<" ";
            i++;
            j++;
        }
    }
}


int main()
{
    int n,m;
    cout << "enter size of array1:";
    cin >> n;
    int a[n];
    cout << "enter array:";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    cout << "enter size of array2:";
    cin >> m;
    int b[m];
    cout << "enter array:";
    for (int i = 0; i < m; i++)
    {
        cin >> b[i];
    }
    
    intersection(a,n,b,m);
}

//time complexity theta(n*n)

