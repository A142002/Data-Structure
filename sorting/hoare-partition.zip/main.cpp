/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <algorithm>
using namespace std;

int partition(int a[],int n,int low,int high)
{
  
  int pivot=a[low];
  int i=low-1,j=high+1;
  while(true)
  {
      do
      {
          i++;
      }while(a[i]<pivot);
      do{
          j--;
      }while(a[j]>pivot);
      if(i>=j)
        return j;
      swap(a[i],a[j]);
  }
}


int main() {
    int n, low,high;

    cout << "Enter size of array1: ";
    cin >> n;
    int a[n];

    cout << "Enter array1: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    cout<<"enter low,high:";
    cin>>low>>high;

    cout<<partition(a,n,low,high)<<endl;
    cout << "after partition: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
    
}


