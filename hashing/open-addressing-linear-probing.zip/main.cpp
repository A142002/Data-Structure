/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h>
using namespace std;


struct myhash
{
    int *arr;
    int cap,size;
    myhash(int c)
    {
        cap=c;
        size=0;
        arr = new int[cap];
        for(int i=0;i<cap;i++)
           arr[i]=-1;
    }
    int hash(int key)
    {
        return key%cap;
    }
    bool insert(int key)
    {
        if(size==cap)
           return false;
        int i=hash(key);
        while(arr[i]!=-1&&arr[i]!=-2&&arr[i]!=key)
           i=(i+1)%cap;
        if(arr[i]==key)
           return false;
        else
        {
            arr[i]=key;
            size++;
            return true;
        }
           
    
    }
    
    bool search(int key)
    {
        int h=hash(key);
        int i=h;
        while(arr[i]!=-1)
        {
        if(arr[i]==key)
          return true;
        i=(i+1)%cap;
        if(i==h)
          return false;
        }
        return false;
        
    }
    
    bool erase(int key)
    {
        int h=hash(key);
        int i=h;
        while(arr[i]!=-1)
        {
            if(arr[i]==key)
               {
                   arr[i]=-2;
                   return true;
               }
               
            i=(i+1)%cap;
            if(i==h)
              return false;
        }
        return false;
    }
    
};

int main()
{
    myhash mh(7);
    mh.insert(40);
    mh.insert(56);
    mh.insert(72);
    if(mh.search(56)==true)
    {
       cout<<"yes"<<endl;
    }
    else
    {
       cout<<"no"<<endl;
    }
       
    mh.erase(56);
    if(mh.search(56)==true)
    {
       cout<<"yes"<<endl;
    }
    else
    {
       cout<<"no"<<endl;
    }
       
    return 0;
    
    
}
