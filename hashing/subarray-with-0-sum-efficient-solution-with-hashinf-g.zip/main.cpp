/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
#include <bits/stdc++.h>
bool isSubarrySum0(int arr[],int n)
{
    unordered_set<int>h;
    int pre_sum=0;
    
    for(int i=0;i<n;i++)
    {
       pre_sum=pre_sum+arr[i];
       if(h.find(pre_sum)!=h.end())
          return 1;
       if(pre_sum==0)
          return 1;
       h.insert(pre_sum);
    }
    return 0;
}

int main()
{
    int n;
    cout<<"enter length of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array element:";
    for (int i = 0; i < n; i++) {
         cin >> arr[i];
          }
    cout<<isSubarrySum0(arr,n)<<" ";
}
