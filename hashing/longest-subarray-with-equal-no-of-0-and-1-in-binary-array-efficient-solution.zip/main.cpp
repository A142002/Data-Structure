/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
#include <bits/stdc++.h>
int isSubarrySum0 (int arr[], int n)
{
    
  for(int i=0;i<n;i++)
  {
      if(arr[i]==0)
        arr[i]=-1;
  }
  unordered_map < int,int>h;
  int pre_sum = 0,res=0,len=0;

  for (int i = 0; i < n; i++)
    {
      pre_sum = pre_sum + arr[i];
      if (pre_sum==len) 
         	res=i+1;
      if(h.find(pre_sum)==h.end())
            h.insert ({pre_sum,i});
      if(h.find(pre_sum-len)!=h.end())
            res=max(res,i-h[pre_sum-len]);
     
    }
  return res;
}

int
main ()
{
  int n, m;
  cout << "enter length of array:";
  cin >> n;
  int arr[n];
  cout << "enter array element:";
  for (int i = 0; i < n; i++)
    {
      cin >> arr[i];
    }
 
  cout << isSubarrySum0 (arr, n) << " ";
}