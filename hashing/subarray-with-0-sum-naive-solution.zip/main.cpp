/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

bool isSubarrySum0(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        int sum=0;
        for(int j=0;j<n;j++)
        {
            sum=sum+arr[j];
            if(sum==0)
              return true;
        }
    }
    return false;
}

int main()
{
    int n;
    int arr[n];
    cout<<"enter length of array:";
    cin>>n;
    cout<<"enter array element:";
    cin>>arr[n];
    cout<<isSubarrySum0(arr,n)<<" ";
}