/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
#include <limits.h>

int isSubarrySum0(int arr[],int n,int m)
{
     int res=INT_MIN;
    for(int i=0;i<n;i++)
    {
        int sum=0;
        for(int j=i;j<n;j++)
        {
            sum=sum+arr[j];
            if(sum==m)
               res=max(res,j-i+1);
              
        }
    }
    return res;
}

int main()
{
    int n,m;
    cout<<"enter length of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array element:";
       for (int i = 0; i < n; i++) {
          cin >> arr[i];
         }
    cout<<"enter sum of array:";
    cin>>m;
    cout<<isSubarrySum0(arr,n,m)<<" ";
}
