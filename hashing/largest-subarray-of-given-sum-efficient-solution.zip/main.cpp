/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
#include <bits/stdc++.h>
int isSubarrySum0 (int arr[], int n,int m)
{
  unordered_map < int,int >h;
  int pre_sum = 0,res=0;

  for (int i = 0; i < n; i++)
    {
      pre_sum = pre_sum + arr[i];
      if (pre_sum==m) 
         	res=i+1;
      if(h.find(pre_sum)==h.end())
            h.insert ({pre_sum,i});
      if(h.find(pre_sum-m)!=h.end())
            res=max(res,i-h[pre_sum-m]);
     
    }
  return res;
}

int
main ()
{
  int n, m;
  cout << "enter length of array:";
  cin >> n;
  int arr[n];
  cout << "enter array element:";
  for (int i = 0; i < n; i++)
    {
      cin >> arr[i];
    }
  cout << "enter sum of subarray:";
  cin >> m; 

  cout << isSubarrySum0 (arr, n,m) << " ";
}
