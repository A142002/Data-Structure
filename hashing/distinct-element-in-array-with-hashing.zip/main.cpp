/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
/*int distinct(int arr[],int n)
{
    int res=0;
    for(int i=0;i<n;i++)
    {
        bool flag=false;
        for(int j=0;j<i;j++)
        {
            if(arr[i]==arr[j])
            {
                flag=true;
                break;
            }
        }
        if(flag==false)
            res++;
    }
    return res;
}*/

int distinct(int arr[],int n){
    int ct=0;
    unordered_set<int>s;
    for(int i=0;i<n;i++)
    {
        s.insert(arr[i]);

    }
    
    cout << "Distinct elements: ";
    for (int element : s) {
        cout << element << " ";
    }
    cout << endl;
    return s.size();
    
}
/*

unordered_set<int>s(arr,arr+n);
return s.size();
*/
int main()
{
    
    int n;
    cout<<"enter size of arr:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int m=distinct(arr,n);
    cout<<m;
    return 0;
    
}