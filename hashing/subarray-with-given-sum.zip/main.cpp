/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

bool isSubarrySum0(int arr[],int n,int m)
{
    for(int i=0;i<n;i++)
    {
        int sum=0;
        for(int j=1;j<n;j++)
        {
            sum=sum+arr[j];
            if(sum==m)
              return true;
        }
    }
    return false;
}

int main()
{
    int n,m;
    cout<<"enter length of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array element:";
       for (int i = 0; i < n; i++) {
          cin >> arr[i];
         }
    cout<<"enter sum of array:";
    cin>>m;
    cout<<isSubarrySum0(arr,n,m)<<" ";
}