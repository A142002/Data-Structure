/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
/*
int anagram(string s1,string s2)
{
   if(s1.length()!=s2.length())
      return false;
      
    sort(s1.begin(),s1.end());
    sort(s2.begin(),s2.end());
    return (s1==s2);
}
*/

const int CHAR=256;
bool anagram(string s1,string s2)
{
    if(s1.length()!=s2.length())
      return false;
    int count[CHAR]={0};
    for(int i=0;i<s1.length();i++)
    {
        count[s1[i]]++;
        count[s2[i]]--;
    }
    for(int i=0;i<CHAR;i++)
    {
        if(count[i]!=0)
           return false;
    }
    return true;
}

int main()
{
    string s1,s2;
    cout<<"enter string1:";
    cin>>s1;
    cout<<"enter string2:";
    cin>>s2;
    cout<<anagram(s1,s2);
}