/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
bool rotationstr(string s1,string s2)
{
    if(s1.length()!=s2.length())
       return false;
    return((s1+s1).find(s2)!=string::npos);
}

int main()
{
    string s1,s2;
    cout<<"enter string1:";
    cin>>s1;
    cout<<"enter pattern:";
    cin>>s2;
    
    cout<<rotationstr(s1,s2);
}
