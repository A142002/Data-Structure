
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;


const int CHAR=256;
int leftmostchar(string s)
{
    int count[CHAR]={0};
    for(int i=0;i<s.length();i++)
    {
        count[s[i]]++;
    }
    for(int i=0;i<s.length();i++)
    {
        if(count[s[i]]==1)
        {
           return s[i];
        }
    }
}

int main()
{
    string s1;
    cout<<"enter string1:";
    cin>>s1;
    
    char res=leftmostchar(s1);
    cout<<res;
}