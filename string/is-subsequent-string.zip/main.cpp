/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
/*bool isSubSeq(string &s1,string &s2,int n,int m)
{
    if(n<m) 
      return false;
    int j=0;
    for(int i=0;i<n && j<m;i++)
    {
        if(s1[i]==s2[i])
            j++;
    }
    return(j==m);
}
*/
//recursion
bool isSubSeq(string &s1,string &s2,int n,int m)
{
    if(m==0)
       return true;
    if(n==0)
       return false;
    if(s1[n-1]==s2[m-1])
       isSubSeq(s1,s2,n-1,m-1);
    else
       isSubSeq(s1,s2,n-1,m);
}
int main()
{
    string s1,s2;
    cout<<"enter string1:";
    cin>>s1;
    int n=s1.length();
    int m=s2.length();
    cout<<"enter string2:";
    cin>>s2;
    cout<<isSubSeq(s1,s2,n,m);
}