
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;


const int CHAR=256;
int naivepat(string txt,string pat)
{
    int n=txt.length();
    int m=pat.length();
    for(int i=0;i<n-m;i++)
    { int j;
        for(j=0;j<m;j++)
        {
            if(pat[j]!=txt[i+j])
              break;
        }
        if(j==m)
          return i;
    }
}

int main()
{
    string txt,pat;
    cout<<"enter string1:";
    cin>>txt;
    cout<<"enter string1:";
    cin>>pat;
    cout<<naivepat(txt,pat);
}