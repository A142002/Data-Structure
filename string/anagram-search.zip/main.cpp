/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;

const int CHAR=256;
bool issame(int CT[],int CP[])
{
    for(int i=0;i<CHAR;i++)
    {
        if(CT[i]!=CP[i])
           return false;
    }
    return true;
}
bool anagramsearch(string txt,string pat)
{
   int CT[CHAR]={0},CP[CHAR]={0};
   for(int i=0;i<pat.length();i++)
   {
       CP[pat[i]]++;
       CT[txt[i]]++;
   }
   for(int i=pat.length();i<txt.length();i++)
   {
       if(issame(CT,CP))
           return true;
       CT[txt[i]]++;
       CT[txt[i-pat.length()]]--;
   }
   return false;
}

int main()
{
    string s1,s2;
    cout<<"enter string1:";
    cin>>s1;
    cout<<"enter pattern:";
    cin>>s2;
    
    cout<<anagramsearch(s1,s2);
}
