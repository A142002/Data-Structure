#include <iostream>
#include <algorithm>
#include <string.h>
using namespace std;

int eD(string s1, string s2, int n, int m)
{
    if (m == 0)
        return n;
    if (n == 0)
        return m;
    if (s1[n - 1] == s2[m - 1])
        return eD(s1, s2, n - 1, m - 1);
    else
        return 1 + min({
            eD(s1, s2, n, m - 1),      // Insert
            eD(s1, s2, n - 1, m),      // Remove
            eD(s1, s2, n - 1, m - 1)   // Replace
        });
}

int main()
{
    int n, m;
    cout << "Enter length of string 1: ";
    cin >> n;
    string s1, s2;
    cout << "Enter string 1: ";
    cin >> s1;
    cout << "Enter length of string 2: ";
    cin >> m;
    cout << "Enter string 2: ";
    cin >> s2;
    cout << eD(s1, s2, n, m);

    return 0;
}
