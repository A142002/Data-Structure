/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string.h>
#include <limits.h>
using namespace std;

int mincoins(int arr[],int n,int val)
{
    int dp[val+1];
    dp[0]=0;
    for(int i=1;i<=val;i++)
    {
        dp[i]=INT_MAX;
    }
    for(int i=1;i<=val;i++)
    {
        for(int j=0;j<n;j++)
    {
        if(arr[j]<=i)
        {
            int sub_res=dp[i-arr[j]];
            if(sub_res!=INT_MAX)
                dp[i]=min(dp[i],sub_res+1);
        }
    }
    }
    return dp[val];
}
int main()
{
   int n,val;
   cout<<"enter size of array:";
   cin>>n;
   int arr[n];
   cout<<"enter elements :";
   for(int i=0;i<n;i++)
   {
       cin>>arr[i];
   }
   cout<<"enter val:";
   cin>>val;
   cout<<mincoins(arr,n,val);
}
