/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string.h>
#include <limits.h>
using namespace std;

int minJump(int arr[],int n)
{
    int dp[n];
    dp[0]=0;
    for(int i=1;i<n;i++)
    {
        dp[i]=INT_MAX;
    }
    for(int i=1;i<n;i++)
    {
        for(int j=0;j<i;j++)
    {
        if(arr[j]+j>=i)
        {
            if(arr[j]!=INT_MAX)
               dp[i]=min(dp[i],dp[j]+1);
        }
    }
    }
    return dp[n-1];
}
int main()
{
   int n,val;
   cout<<"enter size of array:";
   cin>>n;
   int arr[n];
   cout<<"enter elements :";
   for(int i=0;i<n;i++)
   {
       cin>>arr[i];
   }
   cout<<minJump(arr,n);
}
