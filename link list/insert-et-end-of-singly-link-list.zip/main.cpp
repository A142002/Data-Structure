
#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
   if(head==NULL)
   {
       return;
   }
   cout<<(head->data)<<" ";
   printlink(head->next);
}

Node* insertend(Node *head,int x)
{
    Node *temp=new Node(x);
    if(head==NULL) //empty link list temp become head;
       return temp;
    Node *curr=head;
    while(curr->next!=NULL)
    {
        curr=curr->next;
    }
    curr->next=temp;
    return head;
}
int main()
{
    
Node *head=new Node(20);
head->next=new Node(25);
head->next->next=new Node(30);
cout<<" before insert:";
printlink(head);

head=insertend(head,15);
head=insertend(head,10);
head=insertend(head,5);
cout<<endl<<" after insert:";
printlink(head);


}










