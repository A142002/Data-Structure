
#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
   if(head==NULL)
   {
       return;
   }
   cout<<(head->data)<<" ";
   printlink(head->next);
}

Node* insert(Node *head,int x)
{
    Node *temp=new Node(x);
    temp->next=head;
    return temp;
}
int main()
{
    
Node *head=new Node(20);
head->next=new Node(25);
head->next->next=new Node(30);
cout<<" before insert:";
printlink(head);

head=insert(head,15);
head=insert(head,10);
head=insert(head,5);
cout<<endl<<" after insert:";
printlink(head);


}










