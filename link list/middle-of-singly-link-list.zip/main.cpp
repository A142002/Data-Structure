
#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
   if(head==NULL)
   {
       return;
   }
   cout<<(head->data)<<" ";
   printlink(head->next);
}
 Node *printmiddle(Node *head)
 {
     if(head==NULL)
     {
         return NULL;
     }
     Node *slow=head;
     Node *fast=head;
     while(fast!=NULL && fast->next!=NULL)//fast!=NULL- condition suitable for even  && fast->next!=NULL- condition suitable for odd
     {
         slow=slow->next;
         fast=fast->next->next;
     }
     cout<<slow->data;
 }

int main()
{
    
Node *head=new Node(20);
head->next=new Node(25);
head->next->next=new Node(30);
head->next->next->next=new Node(40);
head->next->next->next->next=new Node(60);
printlink(head);
cout<<endl;
printmiddle(head);


}










