#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
   if(head==NULL)
   {
       return;
   }
   cout<<(head->data)<<" ";
   printlink(head->next);
}

int search(Node *head,int x){
    
   if(head==NULL)
   {
       return -1;
   }
   if((head->data)==x)
   {
     return 1; 
   }
   else{
   int res=search(head->next,x);
   if(res==-1)
     return -1;
   else
     return (res+1);
   }

}
int main()
{
    
Node *head=new Node(30);
head->next=new Node(20);
head->next->next=new Node(10);

printlink(head);
int x;
cout<<endl<<"enter number to search:";
cin>>x;
cout<<endl<<"position of " <<x <<" is: "<<search(head,x);

}









