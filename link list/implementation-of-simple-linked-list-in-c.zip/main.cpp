/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};

int main()
{
    Node *head=new Node(30);
    Node *temp1=new Node(20);
    Node *temp2=new Node(10);
    head->next=temp1;
    temp1->next=temp2;
    return 0;
    
/*
Node *head=new Node(30);
head->next=new Node(20);
head->next->next=new Node(10);

*/

    
    
    
    
    
}
