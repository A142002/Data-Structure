#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
    Node *curr=head;
    while(curr!=NULL)
    {
        cout<<curr->data<<" ";
        curr=curr->next;
    }
}

int search(Node *head,int x)
{
   Node *curr=head;
   int p=1;
   while(curr!=NULL)
   {
       
       if(curr->data==x)
       {
          return p;
       }
       else{
           p++;
       curr=curr->next;
       }
   }
   return -1;
}

int main()
{
    
Node *head=new Node(30);
head->next=new Node(20);
head->next->next=new Node(10);
printlink(head);
cout<<endl<<"index of 10 : "<<search(head,40);


}






