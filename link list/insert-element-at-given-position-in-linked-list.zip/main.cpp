
#include<iostream>
using namespace std;
struct Node{
    int data;
    Node *next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
    
    
};
void printlink(Node *head)
{
   if(head==NULL)
   {
       return;
   }
   cout<<(head->data)<<" ";
   printlink(head->next);
}

Node* insertpos(Node *head,int pos,int data)
{
    Node *temp=new Node(data);
    if(pos==1)
     {
         temp->next=head;
           return temp;
     }
     Node *curr=head;
     for(int i=1;i<=pos-2 && curr!=NULL;i++)
     {
         curr=curr->next;
     }
     if(curr==NULL)
        return head;
     temp->next=curr->next;
     curr->next=temp;
     return head;
    
}
int main()
{
    
Node *head=new Node(20);
head->next=new Node(25);
head->next->next=new Node(30);
cout<<" before insert:";
printlink(head);
int pos,data;
cout<<endl<<"Enter position of data where you need to insert:"<<endl;
cin>>pos;
cout<<" Data:"<<endl;
cin>>data;
head=insertpos(head,pos,data);
cout<<endl<<" after insert:";
printlink(head);


}









