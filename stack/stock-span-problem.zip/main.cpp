/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
 void stock_span(int arr[],int n)
 {
     for(int i=0;i<n;i++)
     {
         int span=1;
         for(int j=i-1;j>=0 && arr[j]<=arr[i];j--)
         {
             span++;
         }
         cout<<span<<" ";
     }
 }

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
    cin>>arr[i];
    }
    stock_span(arr,n);
}
