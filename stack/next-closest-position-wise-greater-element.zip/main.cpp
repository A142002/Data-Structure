/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
 /*naivemethod
 void nextlarge(int arr[],int n)
 {
     for(int i=0;i<n;i++)
     {
         int j=0;
         for(j=i+1;j<n;j++)
         {
             if(arr[j]>arr[i])
             {
                cout<<arr[j]<<" ";
                break;
             }
         }
         if(j==n)
           cout<<"-1"<<" ";
     }
 }
*/
//efficient using stack
vector<int>nextlarge(int arr[],int n)
 {
     vector<int>v;
     stack<int>s;
     s.push(arr[n-1]);
    v.push_back(-1);
     for(int i=n-2;i>=0;i--)
     {
         while(s.empty()==false && arr[i]>=s.top())
            s.pop();
        int pg=(s.empty())? -1:s.top();
        v.push_back(pg);
        s.push(arr[i]);
     }
     reverse(v.begin(),v.end());
     return v;
 }
 

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
    cin>>arr[i];
    }
   for(int x: nextlarge(arr,n)){
        cout<<x<< " ";   
    }
}
