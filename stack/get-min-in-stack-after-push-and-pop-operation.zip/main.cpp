/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
a
*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
struct mystack{
    stack<int>ms;
    stack<int>as;
    
void push(int x)
{
    if(ms.empty()==true)
    {
        ms.push(x);
        as.push(x);
        return;
    }
    ms.push(x);
    if(as.top()>ms.top())
    {
        as.push(x);
    }
}
void pop()
{
    if(as.top()==ms.top())
        as.pop();
    ms.pop();
}
int top()
{
    return ms.top();
}
int getmin()
{
    return as.top();
}
};
int main()
{
    mystack s;
    s.push(4);
    s.push(5);
    s.push(8);
    s.push(1);
    cout<<" getmin before pop 1 "<<s.getmin()<<endl;
     s.pop();
    
    cout<<" getmin after pop 1 "<<s.getmin();
    s.pop();
    
}