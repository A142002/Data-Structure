/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;
 
 /*void priviouslarge(int arr[],int n)
 {
     for(int i=0;i<n;i++)
     {
         int j=0;
         for(j=i-1;j>=0;j--)
         {
             if(arr[j]>arr[i])
             {
                cout<<arr[j]<<" ";
                break;
             }
         }
         if(j==-1)
           cout<<"-1"<<" ";
     }
 }
*/
//efficient using stack
void priviouslarge(int arr[],int n)
 {
     stack<int>s;
     s.push(arr[0]);
     cout<<" -1"<<" ";
     for(int i=0;i<n;i++)
     {
         while(s.empty()==false && arr[i]>s.top())
            s.pop();
        int pg=(s.empty())? -1:s.top();
        cout<<pg<<" ";
        s.push(arr[i]);
     }
 }
 

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
    cin>>arr[i];
    }
    priviouslarge(arr,n);
}
