#include <iostream>
#include <stack>
#include <string>

using namespace std;

class Evaluate {
    int top;
    int capacity;
    string* array;

public:
    Evaluate(int capacity) {
        top = -1;
        this->capacity = capacity;
        array = new string[capacity];
    }

    bool isEmpty() {
        return (top == -1);
    }

    string peek() {
        return array[top];
    }

    string pop() {
        if (!isEmpty()) {
            top--;
            return array[top+1];
        }
        else {
            return "$";
        }
    }

    void push(string op) {
        top++;
        array[top] = op;
    }

    int evaluatePostfix(string exp) {
    stack<int> st;
    for (int i = 0; i < exp.length(); i++) {
        if (exp[i] == ' ') {
            continue;
        } else if (isdigit(exp[i])) {
            int operand = 0;
            while (i < exp.length() && isdigit(exp[i])) {
                operand = operand * 10 + (exp[i] - '0');
                i++;
            }
            i--;
            st.push(operand);
        } else {
            int val1 = st.top();
            st.pop();
            int val2 = st.top();
            st.pop();

            switch (exp[i]) {
                case '+':
                    st.push(val2 + val1);
                    break;
                case '-':
                    st.push(val2 - val1);
                    break;
                case '*':
                    st.push(val2 * val1);
                    break;
                case '/':
                    st.push(val2 / val1);
                    break;
            }
        }
    }
    return st.top();
}

};

int main() {
    string exp = "10 2 * 3 5 * + 9-";
    Evaluate obj(exp.length());
    cout << "Postfix evaluation: " << obj.evaluatePostfix(exp) << endl;
    return 0;
}
