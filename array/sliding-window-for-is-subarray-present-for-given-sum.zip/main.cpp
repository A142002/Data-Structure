#include<iostream>
using namespace std;
int slidingwindowforsubarraysum(int arr[],int n,int k)
{
    int s=0,curr=0;
    for(int e=0;e<n;e++)
    {
        curr=curr+arr[e];
        while(curr>k)
        {
            curr=curr-arr[s];
            s++;
        }
        if(k==curr) 
           return true;
    }
    return false;
}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"enter sum:";
    cin>>k;
  cout<<slidingwindowforsubarraysum(arr,n,k);
}


