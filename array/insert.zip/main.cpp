/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int insert(int arr[],int n,int x,int cap,int pos)
  {   
    if(n==cap)
    {
        cout<<n;
    }
    int idx=pos-1;
    for(int i=n-1;i>=idx;i--)
    {
        arr[i+1]=arr[i];
        
    }
    arr[idx]=x;
   for(int k=0;k<n+1;k++)
   {
       cout<<arr[k]<<" ";
   }
  }
    
 int main()
    {
     int arr[]={10,12,13,14};
     insert(arr,4,3,6,2);
    }
