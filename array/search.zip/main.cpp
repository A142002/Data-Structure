/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int search(int arr[],int n,int x)
  {   
    int i;
    for(i=0;i<n;i++)
    {
        if(arr[i]==x)
        {
            return i;
        }
        
    }
    return -1;
    for(int y:arr)
    {
        return y;
    }
  }
    
 int main()
    {
     int arr[]={10,12,13,14};
     cout<<search(arr,4,14);
    }


