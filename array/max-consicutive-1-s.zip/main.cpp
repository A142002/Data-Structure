/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
/*naive solution
int maxconsicutiveones(int arr[],int n)
{
    int res=0;
    for(int i=0;i<n;i++)
    {
        int curr=0;
        for(int j=0;j<n;j++)
        {
            if(arr[j]==1)
               curr++;
            else
               break;
        }
        res=max(curr,res);
    }
    return res;
}
*/
int maxconsicutiveones(int arr[],int n)
{
    int res=0;
     int curr=0;
    for(int i=0;i<n;i++)
    {
       
        if(arr[i]==0)
            curr=0;
        else
        {
           curr++;
           res=max(curr,res);
        }
    }
    return res;
}
int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
  cout<<maxconsicutiveones(arr,n);
}



