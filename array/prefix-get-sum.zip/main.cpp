#include<iostream>
using namespace std;
int getsum(int pre[],int l,int r)
{
if(l==0)
  return pre[r];
return pre[r]-pre[l-1];
}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    int pre[n];
    pre[0]=arr[0];
    for(int i=1;i<n;i++)
        pre[i]=pre[i-1]+arr[i];
    cout<<"enter left and right index";
    int l,r;
    cin>>l;
    cin>>r;
  cout<<getsum(pre,l,r);
}


