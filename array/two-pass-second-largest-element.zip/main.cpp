/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

int large(int arr[],int n)
{
    int max=arr[0];
    int i;
    
    for( i=0;i<n;i++)
    {
        if(max<arr[i])
        {
            max=i;
        }
    }
    return max;
}

int secondlarge(int arr[],int n)
{
    int largest=large(arr,n);
    int res=-1;
    for(int i=0;i<n;i++)
    {
        if(arr[i]!=arr[largest])
        {
            if(res==-1)
              res=i;
            else if(arr[i]>arr[res])
              res=i;
        }
    }
    return res;
    
}

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
   
  cout<<secondlarge(arr,n);
}

