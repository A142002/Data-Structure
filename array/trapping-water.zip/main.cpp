/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

int trappingwater(int arr[],int n)
{
    int res=0;
    int lmax[n],rmax[n];
    lmax[0]=arr[0];
    for(int i=1;i<n;i++)
        lmax[i]=max(arr[i],lmax[i-1]);
    rmax[n-1]=arr[n-1];
    for(int j=n-2;j>=0;j--)
        rmax[j]=max(arr[j],rmax[j+1]);
        
    for(int k=1;k<n-1;k++)
    {
        res=res+(min(lmax[k],rmax[k])-arr[k]);
    }
  return res;      
}

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
  cout<<trappingwater(arr,n);
}



