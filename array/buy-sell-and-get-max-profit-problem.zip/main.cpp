/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

int maxprofit(int arr[],int s,int e)
{
    if(e<=s)
       return 0;
    int profit=0;
    for(int i=s;i<e;i++)
    {
        for(int j=i+1;j<=e;j++)
        {
            if(arr[j]>arr[i])
            {
                int curr_p=arr[j]-arr[i]+maxprofit(arr,s,i-1)+maxprofit(arr,j+1,e);
                profit=max(profit,curr_p);
            }
        }
    }
    return profit;
}

int main()
{
    int n,s,e;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"ender starting :";
    cin>>s;
    cout<<"ender ending:";
    cin>>e;
    
  cout<<maxprofit(arr,s,e);
}



