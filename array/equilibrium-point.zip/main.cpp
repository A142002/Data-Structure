#include<iostream>
using namespace std;
int equilibrium(int arr[],int n)
{
int rs=0;
for(int i=0;i<n;i++)
{
    rs=rs+arr[i];
}
int ls=0;
for(int i=0;i<n;i++)
{
    rs=rs-arr[i];
    if(rs==ls)
      return i;
    ls=ls+arr[i];
}
return false;
}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
  cout<<equilibrium(arr,n);
}


