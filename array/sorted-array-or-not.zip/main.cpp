/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
bool sort(int arr[],int n)//java boolean and only array name
{
    for(int i=0;i<n;i++)//java arr.length
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[i]>arr[j])
               return false;
        }
    }
    return true;
    
}

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
   
   cout<<sort(arr,n);
}

//time complexity O(nsquare)


