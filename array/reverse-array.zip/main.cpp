/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
  int reverse(int arr[],int n)
 {
     int low=0,high=n-1;
     
     while(low<high)
     {
         int temp=arr[low];
         arr[low]=arr[high];
         arr[high]=temp;
         low++;
         high--;
     }
     for(int i=0;i<n;i++)
     {
         cout<<arr[i]<<" ";
     }
 }

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
   
  reverse(arr,n);
}