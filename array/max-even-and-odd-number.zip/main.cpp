#include<iostream>
using namespace std;
int maxevenodd(int arr[],int n)
{
    int res=0;
    for(int i=0;i<n;i++)
    { int count=0;
        for(int j=i;j<n;j++)
        {
           if(j%2==0)
           {
               count++;
           }
            res=max(res,count);
        }
    }
    return res;
}
int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
  cout<<maxevenodd(arr,n);
}

