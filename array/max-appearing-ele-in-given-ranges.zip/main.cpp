#include<iostream>
using namespace std;
int maxeleinrange(int arr[],int arr2[],int n)
{
    int fre[101] = {0}; // Initialize the array with zeros

    for(int i = 0; i < n; i++)
    {
        fre[arr[i]]++;
        fre[arr2[i] + 1]--;
    }

    int res = 0;

    for(int i = 1; i < 101; i++)
    {
        fre[i] = fre[i - 1] + fre[i];
        if(fre[i] > fre[res])
            res = i;
    }

    return res;

}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    int arr2[n];
    cout<<"enter array left:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"enter array right:";
    for(int i=0;i<n;i++)
    {
        cin>>arr2[i];
    }
    
  cout<<maxeleinrange(arr,arr2,n);
}


