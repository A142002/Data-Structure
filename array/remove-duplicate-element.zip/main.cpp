/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include <cmath>
using namespace std;
int rotate(int arr[],int n)
{
    int res =1;
    for(int i=1;i<n;i++)
    {
        if(arr[i]!=arr[res-1])
        {
            arr[res]=arr[i];
            res++;
        }
    }
    return res;
}



int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
   
  n=rotate(arr,n);
  cout<<"after remove:";
  
  for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}