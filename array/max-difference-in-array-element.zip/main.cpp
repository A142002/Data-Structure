/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

/* naive
int maxdiff(int arr[],int n)
{
    int res=arr[1]-arr[0];
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            res=max(res,arr[j]-arr[i]);
        }
        
    }
    return res;
}
*/
//efficient
int maxdiff(int arr[],int n)
{
    int res=arr[1]-arr[0],curr=arr[0];
    for(int i=1;i<n;i++)
    {
       res=max(res,arr[i]-curr);
       curr=min(curr,arr[i]);
        
    }
    return res;
}

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
  cout<<maxdiff(arr,n);
}



