#include<iostream>
using namespace std;
void miniflip(int a[],int n)
{
    for(int i=0;i<n;i++)
    {
        if(a[i]!=a[i-1])
        {
            if(a[i]!=a[0])
               cout<<"from "<<i<<"to ";
            else
               cout<<(i-1)<<endl;
        }
        
    }
        if(a[n-1]!=a[0])
           cout<<(n-1);
    
}
int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
   
  miniflip(arr,n);
}


