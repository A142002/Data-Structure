#include<iostream>
using namespace std;
int maxsumsubarr(int arr[],int n)
{
    int res=arr[0];
    for(int i=0;i<n;i++)
    {
        int sum=0;
        for(int j=i;j<n;j++)
        {
            sum=sum+arr[j];
            res=max(res,sum);
        }
    }
    return res;
}
int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
  cout<<maxsumsubarr(arr,n);
}

