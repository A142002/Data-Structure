/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

struct Queue
{
  int cap,size;
  int *arr;
  Queue(int c)
  {
      cap=c;
      size=0;
      arr=new int[cap];
  }
  int getFront()
  {
      if(isEmpty())
        return -1;
      else
        return arr[0];
  }
  int getRear()
  {
      if(isEmpty())
        return -1;
      else
        return (arr[size-1]);
  }
  bool isEmpty()
  {
      return(size==0);
  }
  bool isFull()
  {
      return(size==cap);
  }
  void insertRear(int x)
  {
      if(isFull())
         return;
      arr[size]=x;
      size++;
  }
  void insertFront(int x)
  {
      if(isFull())
         return;
      for(int i=0;i<size-1;i++)
        {
            arr[i+1]=arr[i];
        }
        arr[0]=x;
        size++;
  }
  int deleteFront()
  {
      if(isEmpty())
        return -1;
      int item=arr[0];
      for(int i=0;i<size-1;i++)
      {
          arr[i]=arr[i+1];
      }
      size--;
      return item;
  }
  int deleteRear()
  {
      if(isEmpty())
         return -1;
      int res=arr[size-1];
      size--;
      return res;
  }
};

int main()
{
    Queue q(4);
    q.insertFront(10);
    q.insertRear(20);
    q.insertFront(30);
     q.insertRear(40);

    cout << q.isFull() << endl;
    cout << q.isEmpty() << endl;
    cout << q.getFront() << endl;
    cout << q.getRear() << endl;
    cout << q.deleteFront() << endl;
    cout << q.deleteRear() << endl;

    return 0;
}

