#include <iostream>
using namespace std;

struct Queue {
    int cap, size, front;
    int *arr;

    Queue(int c) {
        cap = c;
        size = 0;
        front = 0;
        arr = new int[cap];
    }

    int getFront() {
        if (isEmpty())
            return -1;
        else
            return arr[front];
    }

    int getRear() {
        if (isEmpty())
            return -1;
        else
            return arr[(front + size - 1) % cap];
    }

    bool isEmpty() {
        return (size == 0);
    }

    bool isFull() {
        return (size == cap);
    }

    void insertRear(int x) {
        if (isFull())
            return;
        int rear = (front + size) % cap;
        arr[rear] = x;
        size++;
    }

    int deleteRear() {
        if (isEmpty())
            return -1;
        int rear = (front + size - 1) % cap;
        int data = arr[rear];
        size--;
        return data;
    }

    void insertFront(int x) {
        if (isFull())
            return;
        front = (front - 1 + cap) % cap;
        arr[front] = x;
        size++;
    }

    int deleteFront() {
        if (isEmpty())
            return -1;
        int data = arr[front];
        front = (front + 1) % cap;
        size--;
        return data;
    }
};

int main() {
    Queue q(4);
    q.insertFront(10);
    q.insertRear(20);
    q.insertRear(30);

    cout << q.isFull() << endl;
    cout << q.isEmpty() << endl;
    cout << q.getFront() << endl;
    cout << q.getRear() << endl;
    cout << q.deleteFront() << endl;
    cout << q.deleteRear() << endl;

    return 0;
}
