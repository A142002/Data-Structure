/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
bool check(string &str,int start,int end)
{
    if(start>=end)
       return true;
    return(str[start]==str[end])&&check(str,start+1,end-1);
}

int main()
{
  string str;
  cout<<"enter string:"<<endl;
  cin>>str;
  int n=str.length();
  int start=0,end=n-1;
  
 cout<<check(str,start,end);
}