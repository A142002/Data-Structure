/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void subset(string &str, string curr="",int i=0)
{
    if(i==str.length())
    {
        cout<<curr<<" ";
        return;
        
    }
    subset(str,curr,i+1);
    subset(str,curr+str[i],i+1);
    
}

int main()
{
    string str;
    cout<<"enter string:";
    cin>>str;
    subset(str);
}