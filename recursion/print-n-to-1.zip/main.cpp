/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int fun(int n)
{   if(n==0)
      return 0;
    cout<<n<<" ";
    fun(n-1);
}

int main()
{
    int n;
    cout<<"enter n:";
    cin>>n;
    fun(n);
}

//recurrence relation T(n)=T(n-1)+theata(1)
//time complexity theata(n)

