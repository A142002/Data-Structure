/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*
int fact(int n)
{
    if(n==0||n==1)
      return 1;
    return n*fact(n-1);
    
}*/
/*
with tail recursion
*/
int fact(int n,int k)
{   
    if(n==0||n==1)
      return k;
    return fact(n-1,k*n);
    
}

int main()
{
    int n;
    cout<<"enter n:";
    cin>>n;
    int k=1;
    cout<<fact(n,k);
}