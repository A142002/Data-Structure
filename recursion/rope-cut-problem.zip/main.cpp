/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
https://www.onlinegdb.com/#tab-stderr
*******************************************************************************/
#include <iostream>

using namespace std;
int cut(int n,int a,int b,int c)
{
   if(n==0)
     return 0;
   if(n<0)
     return -1;
   int res=max(cut(n-a,a,b,c),max(cut(n-b,a,b,c),cut(n-c,a,b,c)));
   if(res==-1)
      return -1;
   return res+1;
}

int main()
{   
    
    int n,a,b,c;
    cout<<"enter number:";
    cin>>n;
    cout<<"enter possible cuts";
    cin>>a>>b>>c;
    cout<<cut(n,a,b,c);
}