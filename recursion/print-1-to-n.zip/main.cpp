/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int fun(int n)
{   if(n==0)
      return 0;
    fun(n-1);
    cout<<n<<" ";
}

/*
with tail recursion
int fun(int n int k)
{   
    int k=1;
    if(n==0)
      return 0;
    cout<<k<<" ";
    fun(n-1,k+1);
    
}*/
int main()
{
    int n;
    cout<<"enter n:";
    cin>>n;
    fun(n);
}

//recurrence relation T(n)=T(n-1)+theata(1)
//time complexity theata(n)