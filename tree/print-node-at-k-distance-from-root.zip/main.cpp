#include <iostream>

using namespace std;
struct Node{
    int k;
    Node *left,*right;
    Node(int x)
    {
        k=x;
        left=NULL;
        right=NULL;
    }
};
int printDist(Node *root,int x)
{
    if(root==NULL){
        return 0;
    }
    if(x==0)
    {
        cout<<(root->k)<<" ";
    }
    else
    {
        printDist(root->left,x-1);
        printDist(root->right,x-1);
    }
    
}
int main()
{
    Node *root=new Node(10);
    root->left=new Node(20);
    root->right=new Node(30);
    root->right->left=new Node(40);
    root->right->right=new Node(50);
   
   printDist(root,0);
    return 0;
}

