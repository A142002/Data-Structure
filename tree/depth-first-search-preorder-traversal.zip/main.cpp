/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
struct Node{
    int k;
    Node *left,*right;
    Node(int x)
    {
        k=x;
        left=NULL;
        right=NULL;
    }
};
void preorder(Node *root)
{
    if(root!=NULL){
        cout<<root->k<<"->";
        preorder(root->left);
        preorder(root->right);
    }
}
int main()
{
    Node *root=new Node(10);
    root->left=new Node(20);
    root->right=new Node(30);
    root->right->left=new Node(40);
    root->right->right=new Node(50);
   
    preorder(root);
    
}
