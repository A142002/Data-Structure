/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

struct Queue
{
  int cap,size;
  int *arr;
  Queue(int c)
  {
      cap=c;
      size=0;
      arr=new int[cap];
  }
  int getFront()
  {
      if(isEmpty())
        return -1;
      else
        return arr[0];
  }
  int getRear()
  {
      if(isEmpty())
        return -1;
      else
        return (arr[size-1]);
  }
  bool isEmpty()
  {
      return(size==0);
  }
  bool isFull()
  {
      return(size==cap);
  }
  void enqueue(int x)
  {
      if(isFull())
        return;
      else
      {
          arr[size]=x;
          size++;
      }
  }
  int dequeue()
{
    if (isEmpty())
        return -1;

    for (int i = 0; i < size - 1; i++)
    {
        arr[i] = arr[i + 1];
    }
    size--;
    return 0; // or any other appropriate value
}

};

int main()
{
    Queue q(3);
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);

    cout << q.isFull() << endl;
    cout << q.isEmpty() << endl;
    cout << q.getFront() << endl;
    cout << q.getRear() << endl;
    cout << q.dequeue() << endl;

    return 0;
}
