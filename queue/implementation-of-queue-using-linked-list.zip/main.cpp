/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

struct Node
{
    int data;
    Node *next;
    Node(int d)
    {
        data=d;
        next=NULL;
    }
};
struct Queue
{
    int s;
    Node *front, *rear;
    Queue()
    {
        s=0;
        front=NULL;
        rear=NULL;
        
    }
    void enqueue(int x)
    {
        Node *temp=new Node(x);
        if(rear==NULL)
          front=rear=temp;
        rear->next=temp;
        rear=temp;
        s++;
        
    }
    int dequeue()
    {
        if(front==NULL)
          return -1;
        Node *temp=front;
        front=front->next;
        if(front==NULL)
           return NULL;
        int res=temp->data;
        delete(temp);
        s--;
        return res;
        
    }
    int size()
    {
        return s;
    }
    int getFront()
    {
        return front->data;
        
    }
    int getRear()
    {
        return rear->data;
    }
    
    
};

int main()
{
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);

   
    cout << q.size() << endl;
    cout << q.getFront() << endl;
    cout << q.getRear() << endl;
    cout << q.dequeue() << endl;

    return 0;
}