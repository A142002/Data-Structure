/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int trailingfact(int n)
{
   int res=0;
   for(int i=5;i<=n;i=i*5)
   {
       res=res+(n/i);
   }
   return res;
    
}
int main()
{
  int n;
  cout<<"enter number::";
  cin>>n;
  cout<<trailingfact(n);
}
