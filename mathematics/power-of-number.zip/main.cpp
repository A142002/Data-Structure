#include <iostream>

using namespace std;
int countingpower(int n,int k)
{
    int res=1;
    for(int i=0;i<k;i++)
    {
        res=res*n;
    }
 return res;
}

int main()
{
    int n,k;
    cout << "Enter a number: ";
    cin >> n;
    cout << "Enter a counting power: ";
    cin >> k;
    cout<<countingpower(n,k); 
}
