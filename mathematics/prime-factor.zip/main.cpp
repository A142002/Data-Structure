/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int isPrime(int a)
{
    for(int i=2;i<a;i++)
    {
      if(a%i==0)
      {
          return false;
      }
      
    }
    return true;
    
}
    
    
void primeFact(int n)
{
    for(int i=2;i<n;i++)
    {
        if(isPrime(i))
        {
            int x=i;
            while(n%x==0)
            {
                cout<<i<<" ";
                x=x*i;
            }
        }
    }
    
}
    
    

int main()
{
   int p;
   cin>>p;
   primeFact(p);
   return 0;
}
