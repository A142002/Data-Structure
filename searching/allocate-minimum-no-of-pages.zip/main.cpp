#include<iostream>
#include <bits/stdc++.h> 
using namespace std;
int isfeasible(int arr[],int n,int k,int mid)
{
    int sum=0,req=1;
    for(int i=0;i<n;i++)
    {
        if(arr[i]+sum>mid)
        {
            req++;
            sum=arr[i];
        }
        else
        {
            sum=sum+arr[i];
        }
        
    }
    return(req<=k);
}
int minipages(int arr[],int n,int k)
{
    int sum=0,mx=0;
    for(int i=0;i<n;i++)
    {
        sum=sum+arr[i];
        mx=max(mx,arr[i]);
    }
    int low=mx,high=sum,res=0;
    while(low<=high)
    {
      int mid=(low+high)/2;
        if(isfeasible(arr,n,k,mid))
           {
               res=mid;
               high=mid-1;
           }
        else
        {
            low=mid+1;
        }
    }
    return res;
}

int main()
{
    int n,k;
    cout<<"enter no of book:";
    cin>>n;
    int arr[n];
    cout<<"enter no of pages of each book:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"enter no of student:";
    cin>>k;
    
    
  cout<<minipages(arr,n,k);
}




