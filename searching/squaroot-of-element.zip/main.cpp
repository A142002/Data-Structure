#include<iostream>
using namespace std;
int squRoot(int n)
{
    int l=1,r=n,ans=-1;
    int m;
    while(l<=r)
    {
        m=(l+r)/2;
        int msqur=m*m;
        if(msqur==n)
           return m;
        else if(msqur>n)
           r=m-1;
        else
        {
            l=m+1;
            ans=m;
        }
    }
    return ans;
}
int main()
{
    int n,k;
    cout<<"enter element:";
    cin>>n;
    cout<<squRoot(n);
}


