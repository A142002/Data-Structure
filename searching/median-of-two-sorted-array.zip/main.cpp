#include <iostream>

using namespace std;

double findMedianSortedArrays(int nums1[], int m, int nums2[], int n) {
    int merged[m + n];
    int i = 0, j = 0, k = 0;
    
    while (i < m && j < n) {
        if (nums1[i] <= nums2[j]) {
            merged[k] = nums1[i];
            i++;
        } else {
            merged[k] = nums2[j];
            j++;
        }
        k++;
    }

    while (i < m) {
        merged[k] = nums1[i];
        i++;
        k++;
    }

    while (j < n) {
        merged[k] = nums2[j];
        j++;
        k++;
    }

    int totalLength = m + n;
    if (totalLength % 2 == 0) {
        double median = static_cast<double>(merged[totalLength / 2] + merged[(totalLength / 2) - 1]) / 2.0;
        return median;
    } else {
        return static_cast<double>(merged[totalLength / 2]);
    }
}

int main() {
    int arr1[] = {1, 3, 5};
    int arr2[] = {2, 4, 6};
    int m = sizeof(arr1) / sizeof(arr1[0]);
    int n = sizeof(arr2) / sizeof(arr2[0]);
    double median = findMedianSortedArrays(arr1, m, arr2, n);
    cout << "Median: " << median << endl;

    return 0;
}
