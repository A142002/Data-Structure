#include<iostream>
using namespace std;
int searchinsortrotetedarray(int arr[],int n,int x)
{
   int l=0,h=n-1;
   while(l<=h)
   {
       int m=(l+h)/2;
       if(arr[m]==x)
          return m;
       if(arr[l]<arr[m])
       {
           if(arr[l]<=x && arr[m]>x)
                 h=m-1;
           else
              l=m+1;
       }
       else
       {
           if(arr[h]>=x && arr[m]<x)
              l=m+1;
           else
              h=m-1;
       }
   }
   return -1;

}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array left:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"element to search:";
    cin>>k;
    
    
  cout<<searchinsortrotetedarray(arr,n,k);
}



