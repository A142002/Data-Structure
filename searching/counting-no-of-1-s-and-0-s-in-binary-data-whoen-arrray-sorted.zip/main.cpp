/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*//naive code
int countele(int arr[],int n,int x)
{  
  int res=0;
    for(int i=0;i<n;i++)
    {
        if(arr[i]==x)
        
            res++;
        
    }
    
       return res;
   
}

*/

//efficient

int lastocc(int arr[],int n,int x)
{
    int low = 0, high = n - 1;

	while(low <= high)
	{
		int mid = (low + high) / 2;

		if(x > arr[mid])
			low = mid + 1;

		else if(x < arr[mid])
			high = mid - 1;

		else
		{
			if(mid == n-1 || arr[mid + 1] != arr[mid])
				return mid;

			else
				low = mid + 1;
		}

	}

	return -1;
}

int firstocc(int arr[],int n,int x)
{
    int low = 0, high = n - 1;

	while(low <= high)
	{
		int mid = (low + high) / 2;

		if(x > arr[mid])
			low = mid + 1;

		else if(x < arr[mid])
			high = mid - 1;

		else
		{
			if(mid == 0 || arr[mid - 1] != arr[mid])
				return mid;

			else
				high = mid - 1;
		}

	}

	return -1;
}

int countele(int arr[],int n,int x)
{
    int first=firstocc(arr,n,x);
    if(first==-1)
       return -1;
    else
      return (n-first);
}



int main()
{
    int n,x;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter element in array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"enter element to count occurence:";
    cin>>x;
    cout<<countele(arr,n,x);
    
    
}

