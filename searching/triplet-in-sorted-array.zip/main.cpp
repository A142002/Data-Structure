#include<iostream>
using namespace std;
int ispair(int arr[],int n,int sum,int si)
{
    int l=si;
    int h=n-1;
    while(l<h)
    {
        if(arr[l]+arr[h]==sum)
          return true;
        else if(arr[l]+arr[h]<sum)
           l++;
        else
           h--;
    }
    return false;
}
int triplet(int arr[],int n,int x)
{for(int i=0;i<n-2;i++)
{
    if(ispair(arr,n,x-arr[i],i+1)) 
         return true;
}
return false;

}
int main()
{
    int n,k;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array left:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"element sum to search:";
    cin>>k;
    
    
  cout<<triplet(arr,n,k);
}



