#include<iostream>
#include <bits/stdc++.h> 
using namespace std;
int repeatele(int arr[],int n)
{
    bool visit[n];
    memset(visit, false, sizeof(visit));
    for(int i=0;i<n;i++)
    {
        if(visit[arr[i]])
			return arr[i];
		visit[arr[i]] = true;
    }
    return -1;
    
}

int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter array left:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
    
    
  cout<<repeatele(arr,n);
}




