#include<iostream>
using namespace std;
/* naive solution
int peakelement(int arr[],int n)
{
    if(n==1)
       return arr[0];
    if(arr[0]>=arr[1])
      return arr[0];
    if(arr[n-1]>=arr[n-2])
      return arr[n-1];
    for(int i=0;i<n;i++)
    {
        if(arr[i]>arr[i-1] && arr[i]>arr[i+1])
        {
            return arr[i];
        }
        
    }
    return -1;
}*/

int peakelement(int arr[],int n)
{
    int l=0,h=n-1;
    while(l<=h)
    {
        int m=(l+h)/2;
        if((m==0||arr[m]>=arr[m-1]) && (m==n-1||arr[m]>=arr[m+1]))
            return m;
        if(m>0 && arr[m-1]>=arr[m])
           h=m-1;
        
           l=m+1;
    }
    return -1;
}
int main()
{
    int n;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter element of array:";
    for(int i=0;i<n;i++)
    {cin>>arr[i];
    }
    
  cout<<peakelement(arr,n);
}



