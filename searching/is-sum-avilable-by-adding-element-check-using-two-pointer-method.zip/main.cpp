#include<iostream>
using namespace std;

bool twopointersumfount(int arr[],int n,int x)
{
    int i=0,j=n-1;
    while(i<j)
    {
        if(arr[i]+arr[j]==x)
           return true;
        else if(arr[i]+arr[j]>x)
           j--;
        else
           i++;
    }
    return -1;
}
int main()
{
    int n,x;
    cout<<"enter size of array:";
    cin>>n;
    int arr[n];
    cout<<"enter element of array:";
    for(int i=0;i<n;i++)
    {cin>>arr[i];
    }
    cout<<"enter sum to find:";
    cin>>x;
  cout<<twopointersumfount(arr,n,x);
}



