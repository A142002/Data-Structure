/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int search(int arr[],int m,int low,int high)
{
    
    if(low>high)
      return -1;
    int mid=(low+high)/2;
    if(arr[mid]==m)
      return mid;
    else if(arr[mid]<m)
      return search(arr,m,mid+1,high);
    else
      return search(arr,m,low,mid-1);
    
    
}


int main()
{
    int n,m;
    cout<<"size of array:";
    cin>>n;
    int arr[n];
     cout<<"enter array:";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"enter element need to find:";
    cin>>m;
    int low=0,high=n-1;
    cout<<search(arr,m,low,high);
}
