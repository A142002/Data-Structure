#include <bits/stdc++.h>
using namespace std;

class MinHeap {
    int* arr;
    int size;
    int capacity;

public:
    MinHeap(int c) {
        size = 0;
        capacity = c;
        arr = new int[c];
    }

    int left(int i) { return (2 * i + 1); }
    int right(int i) { return (2 * i + 2); }
    int parent(int i) { return (i - 1) / 2; }

    void insert(int x) {
        if (size == capacity)
            return;
        size++;
        arr[size - 1] = x;
        
    }
    
    void display() {
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
  void decreaseKey(int index,int key)
  {
      arr[index]=key;
      while(index!=0 && arr[index]<arr[parent(index)])
      {
          swap(arr[index],arr[parent(index)]);
          index=parent(index);
      }
  }
  
  void deleteele(int i)
  {
      decreaseKey(i,INT_MIN);
      extract;
  }
    
};

int main() {
    MinHeap h(11);
    h.insert(10); 
    h.insert(20);
    h.insert(40);
    h.insert(80);
    h.insert(100);
    h.insert(70);
    cout<<"before decrease key(change key):"<<" ";
    h.display();
    h.decreaseKey(3,5);
    cout<<"after decrease key(change key):"<<" ";
    h.display();
    h.deleteele(3);
    cout<<"after decrease key(change key):"<<" ";
    h.display();
   
    
}

