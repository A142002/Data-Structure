#include <bits/stdc++.h>
using namespace std;

class MinHeap {
    int* arr;
    int size;
    int capacity;

public:
    MinHeap(int c) {
        size = 0;
        capacity = c;
        arr = new int[c];
    }

    int left(int i) { return (2 * i + 1); }
    int right(int i) { return (2 * i + 2); }
    int parent(int i) { return (i - 1) / 2; }

    void insert(int x) {
        if (size == capacity)
            return;
        size++;
        arr[size - 1] = x;
        
    }
    
    void display() {
        for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
   /* Recursive
    void minHeapify(int x)
    {
        
        int lt=left(x),rt=right(x);
        int small=x;
        if(lt<size && arr[lt]<arr[x])
             small=lt;
        if(rt<size && arr[rt]<arr[x])
             small=rt;
        if(small!=x)
        {
            swap(arr[x],arr[small]);
            minHeapify(small);
        }
    }
    */
     
    // iterative require O(1) Auxiliary space only 
    void minHeapify(int x)
    {
        while(true)
        {
        int lt=left(x),rt=right(x);
        int small=x;
        if(lt<size && arr[lt]<arr[x])
             small=lt;
        if(rt<size && arr[rt]<arr[x])
             small=rt;
        if(small!=x)
        {
            swap(arr[x],arr[small]);
            x=small;
        }
        else
        {
            break;
        }
        }
    }
    int extractMin()
    {
        if(size==0)
          return INT_MAX;
        if(size==1)
        {
            size--;
            return arr[0];
        }
        swap(arr[0],arr[size-1]);
        size--;
        MinHeap(0);
        return arr[size];
    }
    
};

int main() {
    MinHeap h(11);
    h.insert(3); 
    h.insert(2);
    h.insert(15);
    h.insert(20);
    cout<<"before minHeapify:"<<" ";
    h.display();
    h.minHeapify(0);
    cout<<"after minHeapify:"<<" ";
    h.display();
    cout<<"min element:"<<h.extractMin();
    return 0;
    
}
