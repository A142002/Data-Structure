/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
#define n 5
int parent[n],r[n];
void initialize()
{
    for(int i=0;i<n;i++)
    {
        parent[i]=i;
        r[i]=0;
    }
}
int find(int x)
{
    if(parent[x]==x)
    {
        return x;
    }
    else 
    {
       return find(parent[x]);
    }
}
void unions(int x,int y)
{
    int x_rep=find(x);
    int y_rep=find(y);
    if(x_rep==y_rep)
       return;
    if(r[x_rep]<r[y_rep])
        parent[x_rep]=y_rep;
    else if(r[y_rep]<r[x_rep])
        parent[y_rep]=x_rep;
    else
    {
        parent[y_rep]=x_rep;
        r[x_rep]++;
    }
}
int main()
{
    initialize();
    unions(0,2);
    unions(2,4);
    cout<<"enter no to check if both are friends or not:";
    int a,b;
    cin>>a>>b;
    if(find(a)==find(b))
    {
        cout<<"yes";

    }
    else{
        cout<<"No";
    }
}
