/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <bits/stdc++.h> 
using namespace std;
struct edge{
    int source,destination,weight;
};
void bellmen(vector<edge>edges,int V,int S)
{
    vector<int>dist(V,INT_MAX);
    dist[S]=0;
    
    for(int count=0;count<V-1;count++)
    {
        for(const edge& e:edges)
        {
            int u=e.source;
            int v=e.destination;
            int w=e.weight;
            if(dist[u]!=INT_MAX && dist[v]>dist[u]+w)
            {
                dist[v]=dist[u]+w;
            }
        }
    }
    
    //negative cycle
     for(const edge& e:edges)
        {
            int u=e.source;
            int v=e.destination;
            int w=e.weight;
            if(dist[u]!=INT_MAX && dist[v]>dist[u]+w)
            {
                cout<<"negative cycle found ";
            }
        }
      
    // print distence 
    for(int i=0;i<V;i++)
    {
        cout<<dist[i]<<" ";
    }
    
    
}
int main()
{
    int V,E,S,W;
    cout<<"enter no of vertex:";
    cin>>V;
    cout<<"enter no of edges:";
    cin>>E;
    vector<edge>edges(E);
    cout<<"enter source, destination, weight:";
    for (int i = 0; i < E; ++i) {
        std::cin >> edges[i].source >> edges[i].destination >> edges[i].weight;
    }
    cout<<"enter source vertex:";
    cin>>S;
    bellmen(edges,V,S);
}