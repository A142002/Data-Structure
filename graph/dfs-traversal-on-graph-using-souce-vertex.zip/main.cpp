/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h> 
using namespace std;
int addEdge(vector<int>adj[],int u,int v)
{
    //undirected graph
    adj[u].push_back(v);
    adj[v].push_back(u);
}
void printGraph(vector<int>adj[],int v)
{
    for(int i=0;i<v;i++)
    {
        for(int x:adj[i])
          cout<<x<<" ";
        cout<<"\n";
        
    }
}
void dferes(vector<int>adj[],int s,bool visited[])
{
    visited[s]=true;
    cout<<s<<" ";
    for(int x:adj[s])
    {
        if(visited[x]==false)
           dferes(adj,x,visited);
    }
}
void DFS(vector<int>adj[],int v,int s)
{
   bool visited[v];
   for(int i=0;i<v;i++)
   {
       visited[i]=false;
   }
   dferes(adj,s,visited);
}
int main()
{
    
   int V,s;
    cout << "Enter the number of vertices: ";
    cin >> V;

    vector<int> adj[V];

    int E;
    cout << "Enter the number of edges: ";
    cin >> E;

    cout << "Enter the edges (u v):\n"<<endl;
    for (int i = 0; i < E; i++)
    {
        int u, v;
        cin >> u >> v;
        addEdge(adj, u, v);
    }
   
    printGraph(adj, V);
   
    
    cout<<endl<<endl<<" BFS"<<endl;
    cout<<"enter source:";
    cin>>s;
    DFS(adj,V,s);
}


