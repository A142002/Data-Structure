/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<bits/stdc++.h> 
using namespace std;
int addEdge(vector<int>adj[],int u,int v)
{
    //undirected graph
    adj[u].push_back(v);
    adj[v].push_back(u);
}
void printGraph(vector<int>adj[],int v)
{
    for(int i=0;i<v;i++)
    {
        for(int x:adj[i])
          cout<<x<<" ";
        cout<<"\n";
        
    }
}

void BFS(vector<int>adj[],int v,int s)
{
    int visited[v+1];
    for(int i=0;i<v;i++)
    {
        visited[i]=false;
    }
    queue<int>q;
    visited[s]=true;
    q.push(s);
    while(q.empty()==false)
    {
        int u=q.front();
        q.pop();
        cout<<u<<" ";
        for(int x:adj[u])
        {
            if(visited[x]==false)
            {
                visited[x]=true;
                q.push(x);
            }
        }
    }
}
int main()
{
    
   int V,s;
    cout << "Enter the number of vertices: ";
    cin >> V;

    vector<int> adj[V];

    int E;
    cout << "Enter the number of edges: ";
    cin >> E;

    cout << "Enter the edges (u v):\n"<<endl;
    for (int i = 0; i < E; i++)
    {
        int u, v;
        cin >> u >> v;
        addEdge(adj, u, v);
    }
   
    printGraph(adj, V);
   
    
    cout<<endl<<endl<<" BFS"<<endl;
    cout<<"enter source:";
    cin>>s;
    BFS(adj,V,s);
}
