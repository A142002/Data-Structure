#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

void addEdge(vector<int> adj[], int u, int v, int w, vector<int> weights[]) {
    adj[u].push_back(v);
    weights[u].push_back(w);
}

void relax(int u, int v, vector<int>& dist, vector<int>& weights) {
    int weight = weights[v];
    if (dist[u] != INT_MAX && dist[v] > dist[u] + weight) {
        dist[v] = dist[u] + weight;
    }
}

vector<int> topo(vector<int> adj[], int V) {
    vector<int> indegree(V, 0);
    for (int i = 0; i < V; i++) {
        for (int x : adj[i]) {
            indegree[x]++;
        }
    }
    queue<int> q;
    vector<int> res;
    for (int i = 0; i < V; i++) {
        if (indegree[i] == 0) {
            q.push(i);
        }
    }
    while (!q.empty()) {
        int p = q.front();
        q.pop();
        res.push_back(p);
        for (int x : adj[p]) {
            if (--indegree[x] == 0) {
                q.push(x);
            }
        }
    }
    return res;
}

void shortestpath(vector<int> adj[], vector<int> weights[], int V, int s) {
    vector<int> topoorder = topo(adj, V);
    vector<int> dist(V, INT_MAX);
    dist[s] = 0;

    for (int u : topoorder) {
        for (int i = 0; i < adj[u].size(); i++) {
            int v = adj[u][i];
            relax(u, v, dist, weights[v]);
        }
    }

    for (int i = 0; i < V; i++) {
        if (dist[i] == INT_MAX)
            cout << "Vertex " << i << ": Not reachable" << endl;
        else
            cout << "Vertex " << i << ": " << dist[i] << endl;
    }
}

int main() {
    int V, s;
    cout << "Enter the number of vertices: ";
    cin >> V;

    vector<int> adj[V];
    vector<int> weights[V];
    int E;
    cout << "Enter the number of edges: ";
    cin >> E;

    cout << "Enter the edges (u v weight):" << endl;
    for (int i = 0; i < E; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        addEdge(adj, u, v, w, weights);
    }

    cout << "Enter source vertex: ";
    cin >> s;
    shortestpath(adj, weights, V, s);

    
}
