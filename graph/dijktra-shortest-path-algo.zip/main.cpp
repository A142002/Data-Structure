/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define V 4
vector<int>dijkstra(int graph[V][V],int s)
{
    vector<int>dist(V,INT_MAX);
    dist[0]=0;
    vector<bool>fin(V,false);
    
    
    for(int count=0;count<V-1;count++)
    {
        int u=-1;
        for(int i=0;i<V;i++)
        {
        if(!fin[i] && (u==-1 || dist[i]<dist[u]))
            u=i;
        }
        fin[u]=true;
        
        for(int v=0;v<V;v++)
        {
            if(graph[u][v]!=0 && !fin[v])
                dist[v]=min(dist[v],graph[u][v]);
        }
    }
    return dist;
}
int main() 
{ 
	int graph[V][V] = { { 0, 5, 8, 0}, 
						{ 5, 0, 10, 15 }, 
						{ 8, 10, 0, 20 }, 
						{ 0, 15, 20, 0 },}; 

   for(int x: dijkstra(graph,0)){
	    cout<<x<<" ";
	}  

	return 0; 
} 

