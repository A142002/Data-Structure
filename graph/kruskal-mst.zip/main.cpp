#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Structure to represent an edge
struct Edge {
    int src, dest, weight;
};

// Structure to represent a graph
struct Graph {
    int V, E;
    vector<Edge> edges;
};

// Function to create a graph
Graph createGraph(int V, int E) {
    Graph graph;
    graph.V = V;
    graph.E = E;
    return graph;
}

// Function to find the parent of a node (used in disjoint set union)
int findParent(vector<int>& parent, int i) {
    if (parent[i] == -1)
        return i;
    return findParent(parent, parent[i]);
}

// Function to perform union of two subsets (used in disjoint set union)
void unionSets(vector<int>& parent, int x, int y) {
    int xset = findParent(parent, x);
    int yset = findParent(parent, y);
    parent[xset] = yset;
}

// Comparison function for sorting edges by weight
bool compareEdges(const Edge& a, const Edge& b) {
    return a.weight < b.weight;
}

// Function to find the minimum spanning tree using Kruskal's algorithm
void kruskalMST(Graph graph) {
    int V = graph.V;
    vector<Edge> result;  // Stores the resulting MST
    vector<int> parent(V, -1);  // Parent array for disjoint set union

    // Sort edges in ascending order of their weights
    sort(graph.edges.begin(), graph.edges.end(), compareEdges);

    int e = 0;  // Index variable used for sorted edges
    int i = 0;  // Index variable used for result vector

    // Keep adding edges to the result vector until V-1 edges are included
    while (e < V - 1 && i < graph.E) {
        Edge nextEdge = graph.edges[i++];

        int x = findParent(parent, nextEdge.src);
        int y = findParent(parent, nextEdge.dest);

        // Add the edge to the result vector only if it doesn't form a cycle
        if (x != y) {
            result.push_back(nextEdge);
            unionSets(parent, x, y);
            e++;
        }
    }

    // Print the resulting MST
    cout << "Minimum Spanning Tree:\n";
    for (i = 0; i < result.size(); i++) {
        cout << result[i].src << " -- " << result[i].dest << " : " << result[i].weight << "\n";
    }
}

int main() {
    int V, E;
    cout << "Enter the number of vertices: ";
    cin >> V;
    cout << "Enter the number of edges: ";
    cin >> E;

    Graph graph = createGraph(V, E);

    cout << "Enter the source, destination, and weight of each edge:\n";
    for (int i = 0; i < E; i++) {
        int src, dest, weight;
        cin >> src >> dest >> weight;
        Edge edge;
        edge.src = src;
        edge.dest = dest;
        edge.weight = weight;
        graph.edges.push_back(edge);
    }

    kruskalMST(graph);

    return 0;
}
